package Taller.Mina.Minas;

import java.util.Scanner;
import java.time.LocalDate;

public class TestMina {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Pedir datos
        System.out.print("Ingrese nombre de la mina: ");
        String nombre = sc.nextLine();

        System.out.print("Ingrese propietario (empresa): ");
        String propietario = sc.nextLine();

        System.out.print("Ingrese mineral que se extrae: ");
        String mineral = sc.nextLine();

        System.out.print("Ingrese reservas estimadas (toneladas): ");
        double reservas = sc.nextDouble();

        System.out.print("Ingrese área de excavación (km2): ");
        double area = sc.nextDouble();

        System.out.print("Ingrese cantidad de pozos: ");
        int pozos = sc.nextInt();

        System.out.print("Ingrese vida esperada (años): ");
        int vida = sc.nextInt();

        System.out.print("Ingrese latitud: ");
        double latitud = sc.nextDouble();

        System.out.print("Ingrese longitud: ");
        double longitud = sc.nextDouble();

        System.out.print("Ingrese año de apertura: ");
        int anio = sc.nextInt();

        System.out.print("Ingrese mes de apertura: ");
        int mes = sc.nextInt();

        System.out.print("Ingrese día de apertura: ");
        int dia = sc.nextInt();

        LocalDate fechaApertura = LocalDate.of(anio, mes, dia);

        // Crear objeto
        Mina mina = new Mina(nombre, propietario, mineral, reservas, vida, fechaApertura, fechaApertura, false, area, pozos, vida, null);

        // Mostrar datos
        System.out.println("\n--- DATOS DE LA MINA ---");
        mina.toString();

        // Probar extracción
        System.out.print("\nIngrese cantidad a extraer (toneladas): ");
        double extraer = sc.nextDouble();

        boolean resultado = mina.extraer(extraer);

        if (resultado) {
            System.out.println("Extracción realizada correctamente.");
        } else {
            System.out.println("No se pudo realizar la extracción.");
        }

        System.out.println("\n--- ESTADO ACTUAL ---");
        mina.toString();

        sc.close();
    }
}
